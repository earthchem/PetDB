''' ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
'''
'''  PetroPlot - Authored by Yong Jun Su and Charles H. Langmuir,
'''
'''  1999-2002
'''  Lamont-Doherty Earth Observatory of Columbia University
'''
'''  Contact ysu@ldeo.columbia.edu
'''
'''  May be redistributed for free,
'''     but may not be sold without the author's explicit permission.
'''
'''  All files are provided "AS IS", with NO WARRANTY,
'''  Comments & suggestions are welcome.
'''
''' ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

You must install browser for PetroPlot documentation.

(Common free browsers: Netscape, Internet Explorer)

If you already have a browser, open the "PetroPlot.htm" to continue.
